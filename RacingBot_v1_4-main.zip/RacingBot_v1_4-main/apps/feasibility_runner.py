"""
RacingBot v1.4 – Feasibility Runner (Stage 2c)

Stage 2c goals:
- Inspect REAL structures of sample inputs
- Print JSON top-level keys and candidate racecard locations
- Print CSV headers and sample rows
- Write diagnostics snapshot
- Still FAIL intentionally
"""

from __future__ import annotations

import csv
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List


def utc_now():
    return datetime.now(timezone.utc)


def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_csv(path: Path) -> List[Dict[str, Any]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        return list(reader)


def main():
    print("=== RacingBot v1.4 Feasibility Runner (Stage 2c: STRUCTURE INSPECTION) ===")

    project_root = Path(__file__).resolve().parents[1]
    raw_dir = project_root / "data" / "raw"
    diagnostics_dir = project_root / "data" / "diagnostics"
    ensure_dir(raw_dir)
    ensure_dir(diagnostics_dir)

    racecards_path = raw_dir / "racecards_sample.json"
    odds_csv_path = raw_dir / "odds_sample.csv"

    run_ts = utc_now().strftime("%Y%m%d_%H%M%S")
    diag_path = diagnostics_dir / f"{run_ts}_feasibility_STAGE2C.json"

    diagnostics: Dict[str, Any] = {
        "stage": "2c",
        "timestamp_utc": utc_now().isoformat(),
        "racecards": {},
        "odds_csv": {},
        "outcome": "FAIL",
        "reason": "Inspection only – no extraction or joins yet"
    }

    # ---- Inspect racecards JSON ----
    print("\n--- RACEcards JSON INSPECTION ---")

    if not racecards_path.exists():
        print("❌ racecards_sample.json not found")
        diagnostics["racecards"]["error"] = "File missing"
    else:
        payload = load_json(racecards_path)

        if isinstance(payload, dict):
            top_keys = list(payload.keys())
            print("Top-level keys:", top_keys)
            diagnostics["racecards"]["top_level_keys"] = top_keys

            # Try common nesting paths
            candidates = {}
            for k in top_keys:
                v = payload.get(k)
                if isinstance(v, list):
                    candidates[k] = len(v)
                elif isinstance(v, dict):
                    for subk, subv in v.items():
                        if isinstance(subv, list):
                            candidates[f"{k}.{subk}"] = len(subv)

            print("Candidate list locations (key → length):")
            for k, v in candidates.items():
                print(f"  {k}: {v}")

            diagnostics["racecards"]["candidate_lists"] = candidates

            # Show first race keys if we can find one
            first_list = None
            for k in candidates:
                parts = k.split(".")
                obj = payload
                for p in parts:
                    obj = obj[p]
                if isinstance(obj, list) and obj:
                    first_list = obj
                    break

            if first_list:
                first_race = first_list[0]
                if isinstance(first_race, dict):
                    print("First race object keys:", list(first_race.keys()))
                    diagnostics["racecards"]["first_race_keys"] = list(first_race.keys())

                    # Check for runners
                    for rk in ("runners", "horses", "participants", "fields"):
                        if rk in first_race and isinstance(first_race[rk], list):
                            print(f"Runner list key detected: '{rk}' (count={len(first_race[rk])})")
                            diagnostics["racecards"]["runner_key"] = rk
                            break
        else:
            print("Racecards payload is not a dict")
            diagnostics["racecards"]["error"] = "Unexpected JSON shape"

    # ---- Inspect odds CSV ----
    print("\n--- ODDS CSV INSPECTION ---")

    if not odds_csv_path.exists():
        print("❌ odds_sample.csv not found")
        diagnostics["odds_csv"]["error"] = "File missing"
    else:
        rows = load_csv(odds_csv_path)

        if not rows:
            print("CSV loaded but contains zero rows")
            diagnostics["odds_csv"]["rows"] = 0
        else:
            headers = list(rows[0].keys())
            print("CSV headers:", headers)
            diagnostics["odds_csv"]["headers"] = headers
            diagnostics["odds_csv"]["rows"] = len(rows)

            print("First 2 rows (truncated):")
            preview = []
            for r in rows[:2]:
                truncated = {k: r[k] for k in list(r.keys())[:6]}
                print(truncated)
                preview.append(truncated)

            diagnostics["odds_csv"]["preview"] = preview

    diag_path.write_text(json.dumps(diagnostics, indent=2), encoding="utf-8")

    print("\nOutcome: FAIL (expected at Stage 2c)")
    print("Reason: Inspection only – no extraction or joins yet")
    print(f"Diagnostics written to: {diag_path}")

    sys.exit(1)


if __name__ == "__main__":
    main()