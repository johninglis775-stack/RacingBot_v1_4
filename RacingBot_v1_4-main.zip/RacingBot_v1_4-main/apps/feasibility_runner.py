"""
RacingBot v1.4 – Feasibility Runner (Stage 3)

Stage 3 goals:
- Extract runner names from racecards
- Extract runner names from odds CSV
- Normalise names deterministically
- Attempt join
- Detect collisions
- HARD FAIL or PASS honestly
"""

from __future__ import annotations

import csv
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Set


def utc_now():
    return datetime.now(timezone.utc)


def normalise_name(name: str) -> str:
    name = name.lower()
    name = re.sub(r"[^a-z0-9 ]", "", name)
    name = re.sub(r"\s+", " ", name)
    return name.strip()


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_csv(path: Path) -> List[Dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def main():
    print("=== RacingBot v1.4 Feasibility Runner (Stage 3: JOIN TEST) ===")

    root = Path(__file__).resolve().parents[1]
    raw_dir = root / "data" / "raw"
    diag_dir = root / "data" / "diagnostics"
    diag_dir.mkdir(parents=True, exist_ok=True)

    racecards_path = raw_dir / "racecards_sample.json"
    odds_path = raw_dir / "odds_sample.csv"

    run_ts = utc_now().strftime("%Y%m%d_%H%M%S")
    diag_path = diag_dir / f"{run_ts}_feasibility_STAGE3.json"

    diagnostics = {
        "stage": "3",
        "timestamp_utc": utc_now().isoformat(),
        "outcome": "FAIL",
        "reason": "",
        "counts": {}
    }

    # ---- Load racecards runners ----
    payload = load_json(racecards_path)
    races = payload.get("racecards", [])

    racecard_names: Dict[str, int] = {}

    for race in races:
        for r in race.get("runners", []):
            name = r.get("name") or r.get("horse") or ""
            if not name:
                continue
            key = normalise_name(name)
            racecard_names[key] = racecard_names.get(key, 0) + 1

    # ---- Load odds runners ----
    odds_rows = load_csv(odds_path)
    odds_names: Dict[str, int] = {}

    for row in odds_rows:
        name = row.get("runner_name") or row.get("runner name") or ""
        if not name:
            continue
        key = normalise_name(name)
        odds_names[key] = odds_names.get(key, 0) + 1

    racecard_set: Set[str] = set(racecard_names.keys())
    odds_set: Set[str] = set(odds_names.keys())

    matched = racecard_set & odds_set
    unmatched_racecards = racecard_set - odds_set
    unmatched_odds = odds_set - racecard_set

    # ---- Collision detection ----
    racecard_collisions = [k for k, v in racecard_names.items() if v > 1]
    odds_collisions = [k for k, v in odds_names.items() if v > 1]

    diagnostics["counts"] = {
        "racecard_runners": len(racecard_set),
        "odds_runners": len(odds_set),
        "matched": len(matched),
        "unmatched_racecards": len(unmatched_racecards),
        "unmatched_odds": len(unmatched_odds),
        "racecard_collisions": racecard_collisions,
        "odds_collisions": odds_collisions,
    }

    print("\n--- JOIN RESULTS ---")
    print("Racecard runners:", len(racecard_set))
    print("Odds runners:", len(odds_set))
    print("Matched runners:", len(matched))
    print("Unmatched racecards:", len(unmatched_racecards))
    print("Unmatched odds:", len(unmatched_odds))

    if racecard_collisions or odds_collisions:
        diagnostics["reason"] = "Name collision detected"
        print("❌ COLLISION DETECTED")
        sys.exit(1)

    if not matched:
        diagnostics["reason"] = "No runners could be joined"
        print("❌ NO JOIN POSSIBLE")
        sys.exit(1)

    diagnostics["outcome"] = "PASS"
    diagnostics["reason"] = "Runner-level join feasible"
    diag_path.write_text(json.dumps(diagnostics, indent=2), encoding="utf-8")

    print("\n✅ FEASIBILITY PASS")
    print("Runner-level odds can be joined to racecards")
    print(f"Diagnostics written to: {diag_path}")
    sys.exit(0)


if __name__ == "__main__":
    main()