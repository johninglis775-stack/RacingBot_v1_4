"""
RacingBot v1.4 – Feasibility Runner

This script is intentionally simple.
Its job is to prove that:
- the project runs,
- diagnostics are written,
- PASS / FAIL is explicit.

Real feasibility logic will be added incrementally.
"""

import json
from datetime import datetime
from pathlib import Path
import sys


def main():
    print("=== RacingBot v1.4 Feasibility Runner ===")

    # Resolve project root (…/RacingBot_v1_4)
    project_root = Path(__file__).resolve().parents[1]
    diagnostics_dir = project_root / "data" / "diagnostics"
    diagnostics_dir.mkdir(parents=True, exist_ok=True)

    run_ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    diagnostics = {
        "run_type": "feasibility",
        "timestamp_utc": datetime.utcnow().isoformat() + "Z",
        "outcome": "FAIL",
        "reason": "Feasibility logic not yet implemented",
        "checks": {
            "racecards_loaded": False,
            "odds_loaded": False,
            "runner_mappable_odds": False,
            "join_possible": False
        }
    }

    diagnostics_path = diagnostics_dir / f"{run_ts}_feasibility_FAIL.json"
    diagnostics_path.write_text(json.dumps(diagnostics, indent=2), encoding="utf-8")

    print("Outcome: FAIL")
    print("Reason: Feasibility logic not yet implemented")
    print(f"Diagnostics written to: {diagnostics_path}")

    # Explicit non-zero exit code = FAIL
    sys.exit(1)


if __name__ == "__main__":
    main()
