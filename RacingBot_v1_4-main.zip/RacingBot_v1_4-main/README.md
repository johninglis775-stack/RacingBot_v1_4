# RacingBot v1.4

Clean restart of RacingBot with strict feasibility gates.

No code committed yet.
